"""Server HTTP cung cap du lieu cam bien va giao dien client web."""

import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
SENSOR_DATA = {"temperature": 23, "humidity": 33}


class SensorHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/sensor":
            # Chuyen du lieu Python thanh JSON va gui ve client.
            body = json.dumps(SENSOR_DATA).encode("utf-8")
            content_type = "application/json; charset=utf-8"
        elif path in ("/", "/client.html", "/evidence.html"):
            filename = "evidence.html" if path == "/evidence.html" else "client.html"
            file_path = ROOT / filename
            if not file_path.is_file():
                self.send_error(404, "File not found")
                return
            body = file_path.read_bytes()
            content_type = "text/html; charset=utf-8"
        else:
            self.send_error(404, "Endpoint not found")
            return

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


def main():
    parser = argparse.ArgumentParser(description="Server cam bien HTTP - Bai 1")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    try:
        with ThreadingHTTPServer((args.host, args.port), SensorHandler) as server:
            print(f"Server: http://{args.host}:{args.port}", flush=True)
            print("API: GET /api/sensor -> temperature=23, humidity=33", flush=True)
            print("Nhan Ctrl+C de dung server.", flush=True)
            server.serve_forever()
    except KeyboardInterrupt:
        print("\nDa dung server.")
    except OSError as exc:
        parser.exit(1, f"Khong khoi dong duoc server: {exc}\n")


if __name__ == "__main__":
    main()
